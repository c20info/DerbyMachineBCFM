import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.*;

public class Gestore {
    public static Grafica gr = new Grafica(0,0,1500,500);//creo un jframe di grandezza 1500*500


    public static void main(String[] args) throws InterruptedException, IOException{//main

        try {
            Image image = new ImageIcon("logo.jpg").getImage();//creo un logo di tipo immagine e lo prendo con getImage
            gr.setIconImage(image);//vado a settare l immagine nella grafica gr (il jframe)
        }catch(Exception e){
            System.out.println("Application icon not found");
        }

        Cavallo cavallo1 = new Cavallo(0,30,"cava1.jpg", 1);//creo 4 cavalli di tipo cavallo con un immagine che partira' in posizione x=0, e ognuno un y diversa
        Cavallo cavallo2 = new Cavallo(0,150,"cava2.jpg", 2);
        Cavallo cavallo3 = new Cavallo(0,280,"cava3.jpg", 3);
        Cavallo cavallo4 = new Cavallo(0,390,"cava4.jpg", 4);

        gr.menu();//aggiungo al jframe il menu
        gr.add(cavallo1,0);//aggiungo i 4 cavalli alla grafica(jframe)
        gr.add(cavallo2,0);
        gr.add(cavallo3,0);
        gr.add(cavallo4,0);
        while(Cavallo.vincitore<0){
            cavallo1.muovi();//faccio muovere tutti e 4 i cavalli
            cavallo2.muovi();
            cavallo3.muovi();
            cavallo4.muovi();
            Thread.sleep(10);

        }
        Thread.sleep(1000);
        gr.getContentPane().removeAll();

        gr.repaint();
        JLabel vittoria=new JLabel();
        vittoria.setBounds(gr.getWidth()/2-515, gr.getHeight()/2 - 150, 200, 20);
        gr.setSize(300, 300);
        gr.add(vittoria, 0);
        vittoria.setText("Ha vinto il cavallo: "+ Cavallo.vincitore);




    }
}