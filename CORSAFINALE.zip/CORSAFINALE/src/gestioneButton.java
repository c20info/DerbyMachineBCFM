import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;

public class gestioneButton extends JPanel{

    public static final Color BUTTON_COLOR = new Color(220,220,220);                //gainsboro color
    private JLabel label;
    private Color color;
    private gestioneButton button;
    private boolean activated;

    public gestioneButton(int posx, int posy, String msg, Color color, Background background) {
        this.label = new JLabel();
        this.button = this;
        this.activated = false;
        this.setBounds(posx - 70 / 2, posy - 40 / 2, 50, 40);
        this.setLayout(null);
        labelManager(msg);
        this.color = color;
        this.add(label);
        this.setVisible(true);
        Gestore.gr.add(button);
        this.addMouseListener(new MouseAdapter(){
            @Override
            public void mousePressed (MouseEvent e) {

                button.setBackground(new Color(color.getRed() - 30, color.getGreen() - 30, color.getBlue() - 30));
            }

            @Override
            public void mouseReleased (MouseEvent e) {
                button.setBackground(new Color(color.getRed(), color.getGreen(), color.getBlue()));
                button.activated = true;
                background.setVisible(true);//setto lo sfondo visibile appena premo start per far iniziare la gara


            }
        });
    }

    public boolean isActive() {
        System.out.println(button.activated);
        return button.activated;
    }

    private void labelManager(String msg) {
        label = new JLabel(msg, SwingConstants.RIGHT);
        label.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 22));
        label.setForeground(Color.BLACK);
        label.setBounds(0, 0, this.getWidth(), this.getHeight());
        this.add(label);
    }

    @Override
    public void setBackground(Color backgroundColor)
    {
        this.color = backgroundColor;
        this.repaint();
    }

    @Override
    public void paintComponent(Graphics g) {
        g.setColor(color);
        g.fillRoundRect(0, 0, this.getWidth(), this.getHeight(), 10, 10);
    }
}
