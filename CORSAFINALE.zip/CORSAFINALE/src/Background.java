import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Background extends JPanel {
    private BufferedImage background;

    public Background() {
       try {
            this.background = ImageIO.read(new File("sfondo.jpg"));//do l immagine sfondo come background
        } catch (Exception e) {
        }
        this.setBounds(0,0,1500,500);//grandezza del jframe della gara
    }



    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        g.drawImage(background.getScaledInstance(Gestore.gr.getWidth(), Gestore.gr.getHeight(),0),0 ,0,this);
    }
}