import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

public class Grafica extends JFrame {
    public static int w;//grandezza
    public static int h;//altezza
    private Grafica g;//pannello jframe
    private Background background;//sfondo di tipo background
    private int gett;//ngettoni

    public Grafica(int x, int y, int w, int h){
        this.w = w;//grandezza
        this.h = h;//altezza
        this.setBounds(x,y,w,h);//locazione con x y grandezza e altezza
        this.setTitle("Horse Race");//titolo del jframe
        this.background=new Background();//inizializzo
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLayout(null);
        this.setResizable(false);
        this.setVisible(true);//setto la visibilita attiva
        this.add(background, 0);//aggiungo il background
        background.setVisible(false);//Setto inizialmente la visibilita del background disabilitata
        g = this;
        gett= new Random().nextInt(10)+1;//do un valore random tra 1 e 10 ai gettoni
    }

    public void menu(){//menu iniziale
        radioButton b = new radioButton(30,30);//creo un bottone iniziale di tipo radio
        b.startButton(30,30);//creo un bottone start iniziale di grandezza 30x30
        Gestore.gr.remove(b);//rimuovo dalla grafica il bottone
        Gestore.gr.setSize(1200,500);//do una grandezza diversa all jframe per la gara
    }


    public void remove(radioButton rb){//metodo che mi rimuove i bottoni
        this.remove(rb.pulsante);//rimuovo lo start
        this.remove(rb.r1);//rimuovo i diversi selezionatori di cavalli
        this.remove(rb.r2);
        this.remove(rb.r3);
        this.remove(rb.r4);
        this.remove(rb.fgett);//rimuovo la scritta ngettoni
        this.remove(rb.get);//rimuovo il numero gettoni
    }

    public class  radioButton extends ButtonGroup{

        private gestioneButton pulsante = new gestioneButton(175,110,"start ",Color.GRAY, background);//creo un bottone start
        private JRadioButton r1=new JRadioButton("cavallo-1");//creo i diversi bottoni per selezionare i cavalli
        private JRadioButton r2=new JRadioButton("cavallo-2");
        private JRadioButton r3=new JRadioButton("cavallo-3");
        private JRadioButton r4=new JRadioButton("cavallo-4");
        private JLabel fgett = new JLabel("N° GETTONI");//scritta di ngettoni
        private JLabel get = new JLabel(String.valueOf(gett));//numero di gettoni

        public radioButton(int cordx, int cordy){
            r1.setBounds(120,150,100,30);//posizione dei diversi bottoni
            r2.setBounds(120,250,100,30);
            r3.setBounds(120,350,100,30);
            r4.setBounds(120,450,100,30);
            fgett.setBounds(145,15,150,30);//posizione della scritta ngettoni
            get.setBounds(145,45,100,30);//posizione del numero di gettoni
            g.add(pulsante,0);//aggiungo alla grafica il pulsante start
            g.add(r1,0);//aggiungo i bottoni cavallo-1 ecc.
            g.add(r2,0);
            g.add(r3,0);
            g.add(r4,0);
            g.add(fgett, 0);//aggiungo alla grafica la scritta NGETTONI
            g.add(get,0);//aggiungo il numero di gettoni
            this.add(r1);
            this.add(r2);
            this.add(r3);
            this.add(r4);
            g.setSize(350,550);//setto la grandezza del pannello
        }

        public int startButton(int cordx, int cordy){//metodo dello start button che mi seleziona il cavallo
            int horseSelected = 0;
            while(!pulsante.isActive()) {
                horseSelected = getSelected();
            }
            return horseSelected;
        }

        public int getSelected(){//dopo aver selezionato il cavallo mi dira quale ho selezionato
            if(r1.isSelected())
                return 1;
            if(r2.isSelected())
                return 2;
            if(r3.isSelected())
                return 3;
            if(r4.isSelected())
                return 4;
            return 0;
        }
    }
}
