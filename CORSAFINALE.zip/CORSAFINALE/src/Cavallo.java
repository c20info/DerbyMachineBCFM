import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

public class Cavallo extends JPanel {
    private int cordx;//cordinate x del cavallo
    private int cordy;//cordinate y del cavallo
    private int num;
    private JLabel vincita;
    public static int vincitore=-1;
    private BufferedImage img;//immagine che daremo al cavallo

    public Cavallo(int cordx, int cordy, String nome, int num) throws IOException{
        this.cordx = cordx;
        this.cordy = cordy;
        img = ImageIO.read(new File(nome));
        this.num=num;

        this.setBounds(cordx,cordy, 600,600);//posiz
    }

    public void muovi() {//metodo per muovere il cavallo fino alla posizione
        if (cordx < 1200 - 250) {//1200-250 del frame
            cordx += new Random().nextInt(7) + 1;//con un movimento random tra 1 e 7 per ogni cavallo
        }else if(vincitore<0){
            vincitore=num;
        }
        this.setBounds(cordx, cordy, 60, 60);
    }

    public void setCordx(int cordx){//set della cord x

        this.cordx = cordx;
    }
    public int getCordx(){//get per prendere la cord x

        return cordx;
    }
    @Override
    public void paintComponent(Graphics g){
        g.setColor(Color.RED);
        g.fillRect(0,0,60,60);
        g.drawImage(img.getScaledInstance(60,60,0),0,0,this);
    }
}
